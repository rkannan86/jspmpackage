define(["github:c3js/c3@0.4.11/c3.js"], function(main) {
  return main;
});