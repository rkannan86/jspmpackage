basePath = '..';
files = [
  JASMINE,
  JASMINE_ADAPTER,
  'components/jquery/dist/jquery.js',
  'components/jquery-ui/jquery-ui.min.js',
  'components/angular/angular.js',
  'components/angular-mocks/angular-mocks.js',
  'src/angular-dragdrop.js',
  'test/spec/*.js'
];
singleRun = true;
browsers = [ 'Chrome' ];