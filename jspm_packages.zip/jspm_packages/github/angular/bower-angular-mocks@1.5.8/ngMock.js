/* */ 
"format cjs";
require('./angular-mocks');
module.exports = 'ngMock';
