/* */ 
"format cjs";
require('./angular-animate');
module.exports = 'ngAnimate';
